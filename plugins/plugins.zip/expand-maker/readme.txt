=== Read More by Edmon ===
Contributors: Edmon Parker
Tags: Tags: read more ,expander, expand, expandable,read less ,Accordion,show more,Do more,WP show more, Expanding, collapsible, display, expandable content,  show more, hidden, hide, javascript, jquery, more, read me,  shortcode
Requires at least: 3.8
Tested up to: 4.9.5
Stable tag: 2.1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The best wordpress "Read more" plugin to help you show or hide your long content.

== Description ==
Read More is the best wordpress **Read More** plugin to help you show or hide your long content.

With the help of **Read More** plugin you can make website with long content more beautiful. The part of the page you don`t want to see immediately,will be hidden after inserting it in the short code and will open by clicking the button.
Use it to toggle (show/hide) blocks of text, by inserting a simple shortcode:

Read More by Edmon is a WordPress plugin that allows you include text which won't be visible to users unless they press "Read More" button.
Its purpose is to boost your SEO and your visitors' experience, by allowing you to include tons of data readable by search engines, without affecting your visitors in a negative way.

How to create read more popup example

https://www.youtube.com/watch?v=Iz8U2Ly-VN8

How to create read more button

https://www.youtube.com/watch?v=ML9Xmbs0TvU

** Read more - Features: **

* button width - button custom dimension
* button height - button custom dimension
* Font size - button custom font size
* Expand animation duration - Expand custom animation duration

** Read more - PRO features: **

* button background color - custom color.
* button font family - button font family from google fonts.
* button color - button text custom color.
* button border radius - button border radius.
* button horizontal alignment - button horizontal alignment.
* button vertical alignment - button vertical alignment.
* button vertical alignment - button vertical alignment.
* more only on mobile devices - after activating this option, Read more will be shown only on mobile devices.
* button background color on hover effect - after mouse hover effect read more button change background color.
* button text color on hover effect - after mouse hover effect read more button change text color.
* Popup type
* Popup width
* Popup height
* Popup max width
* Popup max height
* Popup initial width
* Popup initial height
* Popup show close button
* Popup dismiss on overlay click
* Popup dismiss on esc key
* Popup overlay color
* Popup content color
* Popup content padding

<a href="http://edmion.esy.es/" target="_blank" >Get Read More PRO package</a>

Shortcode example:
[expander_maker more="Read more" less="Read less"]Hidden text[/expander_maker]


We do web development and if you need a developer or if you think you have found a bug in Read more plugin, if you have any question, please feel free to contact us by this email <b>edmon.parker@gmail.com</b>.

== Changelog ==
= 2.1.4 =
* Remove Settings after uninstallation
* User role who can use plugin
* On of logic
* Button border (pro)
* Box shadow (pro)
* Bug fixed

= 2.1.3 =
* Read more shortcode more and less names improvement

= 2.1.2 =
* Clone option
* Hidden content padding (pro)
* Code improvement

= 2.1.1 =
* New option Animation behavior
* Design improvement

= 2.1.0 =
* Fixed js button toggle issue
* Code cleanup

= 2.0.9 =
* Button font weight (new)
* Button 5 new fonts (new PRO)
* hidden content text color (new PRO)
* hidden content background color (new PRO)
* popup overlay color (new PRO)
* popup content color (new PRO)
* popup content padding (new PRO)
* Bug fixed
* Code improvement

= 2.0.3 =
* Button hover effect (new option)

= 2.0.2 =
* Bug fixed
* New read more type Popup (Pro)
* code improvement

= 2.0.1 =
* posibility add shortcode to hidden content.
* Js functionality improvement.
* Bug fixed.

= 2.0.0 =
* Changed admin dashboard
* Unlimited read more button
* Beckend and frontend functionality chnages
* hover text color (pro)
* hover background color(pro)

= 1.2.1 =
* Security fixed
* Code improvement

= 1.2.0 =
* Multisite support.
* Bug fixed

= 1.1.9 =
* short code improvement now you can use short code like this [expander_maker]Hidden text[/expander_maker]
	Where default more = "Read more" and less = "Read less".
* code improvement

= 1.1.8 =
* Bug fixed
* code improvement

= 1.1.7 =
* multiple values of “more” and “less” examples
[expander_maker more="Read more" less="Read less"]Hidden text[/expander_maker]
[expander_maker more="Read more1" less="Read less1"]Hidden text[/expander_maker]
* Bug fixed

= 1.1.6 =
* Bug fixed
* Change Font Family (Pro)
* Show only on mobile devices (Pro)

= 1.0.1 =
* Fixed button style.

= 1.0.2 =
* Bug fixed.
* Changed shortcode name
* Fixed button style.

= 1.0.3 =
* Bug fixed.
* Button width option.
* Button height option.
* Animation duration option.
* Fixed button style.

= 1.1.3 =
* Bug fixed.
* Font size.
* Pro version.
* Admin view change.

= 1.1.5 =
* Bug fixed.

== Frequently Asked Questions ==

Coming soon.

== Screenshots ==
1. Read mores
2. Read more types
3. Read more button type options
4. Read more popup type options
5. Read more popup 1 theme
6. Read more popup 3 theme
7. Read more popup 4 theme
8. Read more popup 5 theme