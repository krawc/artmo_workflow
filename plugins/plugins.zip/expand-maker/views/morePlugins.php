<h1>Feature plugins</h1>
<div class="plugin-group" id="yrm-plugins-wrapper">

	<div class="plugin-card" onclick="window.open('https://wordpress.org/plugins/contact-form-master/')">
		<div class="plugin-card-top">
			 <a href="https://wordpress.org/plugins/contact-form-master/" target="_blank" class="plugin-icon"><div class="plugin-icon" id="plugin-icon-contact-form"></div></a>
			 <div class="name column-name">
				 <h4><a href="https://wordpress.org/plugins/contact-form-master/" target="_blank">Contact Form</a></h4>
			 </div>
			<div class="desc column-description">
				<p>Contact form is the most complete Contact form plugin. You can create different 'contact forms' with different fields.</p>
				<div class="column-compatibility"><span class="compatibility-compatible"><strong>Compatible</strong> with your version of WordPress</span></div>
			</div>
		</div>
	</div>
	<div class="plugin-card" onclick="window.open('https://wordpress.org/plugins/popup-master/')">
		<div class="plugin-card-top">
			 <a href="https://wordpress.org/plugins/popup-master/" target="_blank" class="plugin-icon"><div class="plugin-icon" id="plugin-icon-popup"></div></a>
			 <div class="name column-name">
				 <h4><a href="https://wordpress.org/plugins/popup-master/" target="_blank">Popup master</a></h4>
			 </div>
			<div class="desc column-description">
				<p>Popup Maker is the best Popup Builder, Popup Maker, Pop-up, Popups,Exit intent popup plugin.</p>
				<div class="column-compatibility"><span class="compatibility-compatible"><strong>Compatible</strong> with your version of WordPress</span></div>
			</div>
		</div>
	</div>

</div>