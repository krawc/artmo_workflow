<?php
class ButtonTypeReadMore extends ReadMore {

}