<?php
require_once(dirname(__FILE__).'/config.php');

require_once(YRM_CLASSES.'ReadMoreInstall.php');

ReadMoreInstall::uninstall();