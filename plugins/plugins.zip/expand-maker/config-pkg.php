<?php
if(!defined('YRM_PKG')) {
	define("YRM_PKG", YRM_FREE_PKG);
}