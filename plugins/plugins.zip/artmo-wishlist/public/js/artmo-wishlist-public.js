(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	 function display_empty_wishlist() {
		 var products = $('.artmo-wishlist ul.products li.product').length;
		 if (products === 0) {
			 $('.artmo-wishlist.wishlist-container').html('<div class="artmo-wishlist empty-wishlist wishlist-container"><i class="ion ion-ios-filing-outline"></i><h2>No products on your wishlist. Yet.</h2><button class="artmo-wishlist btn-see-collection"><a href="' + wishlist.home_url + '/collection">SEE THE COLLECTION</a></button></div>');
		 }
	 }

	 $(function() {
		 $('.artmo-wishlist.add-to-wishlist').click(function(){
			 var button = $(this);
			 button.html('<i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i>');
			 var id = $(this).data('id');
			 var data = {
				 action: 'artmo_add_to_wishlist',
				 post_id: id,
			 }
			 $.post(wishlist.ajax_url, data, function(response) {
				 if(response) {
					 console.log(response);
					 button.html('<a href="/artmo-wishlist">SEE ON WISHLIST</a>');
					 button.removeClass('add-to-wishlist').addClass('see-on-wishlist');
				 }
			 });
		 });

		 $('li.product .delete-from-wishlist').click(function(){
			 var button = $(this);
			 button.addClass('wl-delete-processing');
			 button.html('<i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i>');
			 var id = $(this).data('id');
			 var data = {
				 action: 'artmo_delete_from_wishlist',
				 post_id: id,
			 }
			 $.post(wishlist.ajax_url, data, function(response) {
				 if(response) {
					 console.log(response);
					 button.removeClass('wl-delete-processing');
					 button.parent().fadeOut( 300, function() {
						 button.parent().remove();
						 display_empty_wishlist();
					 }
					);
				 }
			 });
		 });

	 });



})( jQuery );
