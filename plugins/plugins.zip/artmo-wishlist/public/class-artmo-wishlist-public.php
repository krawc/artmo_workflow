<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       konradkrawczyk.com
 * @since      1.0.0
 *
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/public
 * @author     Konrad Krawczyk <konrad@artmo.com>
 */
class Artmo_Wishlist_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Artmo_Wishlist_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Artmo_Wishlist_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/artmo-wishlist-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Artmo_Wishlist_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Artmo_Wishlist_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/artmo-wishlist-public.js', array( 'jquery' ), $this->version, false );

		wp_localize_script( $this->plugin_name, 'wishlist', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'home_url' => get_home_url()
		));

	}

	public function register_shortcodes() {
		add_shortcode( 'artmo-wishlist', array( $this, 'display_artmo_wishlist' ) );
	}

	public function display_artmo_wishlist() {
		$user_id = get_current_user_id();
		$wishlist = get_user_meta($user_id, 'artmo_wishlist', true);
		if (isset($user_id) && !empty($user_id)) {
			if(isset($wishlist) && !empty($wishlist)) {
				$wishlist = array_values($wishlist);
				$args = array(
					'post_type' => 'product',
					'post__in' => $wishlist
				);
				$loop = new WP_Query( $args );
				if ( $loop->have_posts() ) {
					?>
					<div class="woocommerce artmo-wishlist wishlist-container">
						<ul class="products">
					<?php
					while ( $loop->have_posts() ) : $loop->the_post();
						?>
							<li <?php wc_product_class(); ?>>
								<div class="delete-from-wishlist" data-id="<?php echo get_the_ID(); ?>">
									<i class="ion ion-ios-close-empty"></i>
								</div>
								<?php
								/**
								 * Hook: woocommerce_before_shop_loop_item.
								 *
								 * @hooked woocommerce_template_loop_product_link_open - 10
								 */
								do_action( 'woocommerce_before_shop_loop_item' );
								/**
								 * Hook: woocommerce_before_shop_loop_item_title.
								 *
								 * @hooked woocommerce_show_product_loop_sale_flash - 10
								 * @hooked woocommerce_template_loop_product_thumbnail - 10
								 */
								do_action( 'woocommerce_before_shop_loop_item_title' );
								/**
								 * Hook: woocommerce_shop_loop_item_title.
								 *
								 * @hooked woocommerce_template_loop_product_title - 10
								 */
								do_action( 'woocommerce_shop_loop_item_title' );
								/**
								 * Hook: woocommerce_after_shop_loop_item_title.
								 *
								 * @hooked woocommerce_template_loop_rating - 5
								 * @hooked woocommerce_template_loop_price - 10
								 */
								do_action( 'woocommerce_after_shop_loop_item_title' );
								/**
								 * Hook: woocommerce_after_shop_loop_item.
								 *
								 * @hooked woocommerce_template_loop_product_link_close - 5
								 * @hooked woocommerce_template_loop_add_to_cart - 10
								 */
								do_action( 'woocommerce_after_shop_loop_item' );?>
							</li>
						<?php
					endwhile;
					?>
				</ul>
			</div>
				<?php
			}
				wp_reset_postdata();
			} else {?>
					<div class="artmo-wishlist empty-wishlist wishlist-container">
						<i class="ion ion-ios-filing-outline"></i>
						<h2><?php echo __('No products on your wishlist. Yet.', 'artmo-wishlist');?></h2>
					<button class="artmo-wishlist btn-see-collection">
						<a href="<?php echo get_home_url(); ?>/collection">
							<?php echo __('SEE THE COLLECTION', 'artmo_wishlist');?>
						</a>
					</button>
					</div>
			<?php	}
		}
	}

	public function display_add_to_wishlist_button() {
		global $woocommerce, $post, $product;
		$product_id = $post->ID;
		$user_id = get_current_user_id();
		$wishlist = get_user_meta($user_id, 'artmo_wishlist', true);

		if (isset($user_id) && !empty($user_id)) {
			if(isset($wishlist[$product_id]) && !empty($wishlist[$product_id])) {
				echo '<div class="artmo-wishlist see-on-wishlist" data-id="'. $product_id .'">'
							.'<a href="'. get_home_url() .'/artmo-wishlist">'
							. __('SEE ON WISHLIST', 'artmo-wishlist')
							.'</a>'
							.'</div>';
			} else {
				echo '<div class="artmo-wishlist add-to-wishlist" data-id="'. $product_id .'">'. __('ADD TO WISHLIST', 'artmo-wishlist').'</div>';
			}
		} else {
				echo '<div class="artmo-wishlist see-on-wishlist" data-id="'. $product_id .'">'
							.'<a href="'. get_home_url() .'/sign-up">'
							. __('ADD TO WISHLIST', 'artmo-wishlist')
							.'</a>'
							.'</div>';
		}
	}

	public function artmo_add_to_wishlist() {

		global $_POST;

		$user_id = get_current_user_id();
		$wishlist = get_user_meta($user_id, 'artmo_wishlist')[0];
		if (empty($wishlist)) {
			$wishlist = array();
		}

		$product_id = $_POST['post_id'];

		if(isset($product_id) && !empty($product_id)) {
			$wishlist[$product_id] = $product_id;
		}

		// $wishlist = array();

		update_user_meta($user_id, 'artmo_wishlist', $wishlist);

		echo 'success';

		die();
	}

	public function artmo_delete_from_wishlist() {

		global $_POST;

		$user_id = get_current_user_id();
		$wishlist = get_user_meta($user_id, 'artmo_wishlist')[0];
		$product_id = $_POST['post_id'];

		if(isset($product_id) && !empty($product_id)) {
			unset($wishlist[$product_id]);
		}

		// $wishlist = array();

		update_user_meta($user_id, 'artmo_wishlist', $wishlist);

		echo 'success';

		die();
	}

}
