<?php

/**
 * Fired during plugin deactivation
 *
 * @link       konradkrawczyk.com
 * @since      1.0.0
 *
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/includes
 * @author     Konrad Krawczyk <konrad@artmo.com>
 */
class Artmo_Wishlist_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
