<?php

/**
 * Fired during plugin activation
 *
 * @link       konradkrawczyk.com
 * @since      1.0.0
 *
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Artmo_Wishlist
 * @subpackage Artmo_Wishlist/includes
 * @author     Konrad Krawczyk <konrad@artmo.com>
 */
class Artmo_Wishlist_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
