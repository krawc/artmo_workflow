// For Color Field Type

jQuery(document).ready(function($){
    $('.pickcolor-field').wpColorPicker();
});

