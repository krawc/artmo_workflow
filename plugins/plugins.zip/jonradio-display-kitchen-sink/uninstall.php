<?php
//	Ensure call comes from WordPress, not a hacker or anyone else trying direct access.
if ( !defined( 'WP_UNINSTALL_PLUGIN' ) )
	exit ();

/*	Delete Settings.
*/
//	None yet

?>