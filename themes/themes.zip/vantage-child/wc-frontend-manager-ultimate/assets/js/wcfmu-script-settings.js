jQuery( document ).ready( function( $ ) {
	
});