<?php

define('WCFMu_TOKEN', 'wcfmu');

define('WCFMu_TEXT_DOMAIN', 'wc-frontend-manager-ultimate');

define('WCFMu_VERSION', '3.5.5');

define('WCFMu_SERVER_URL', 'https://wclovers.com');

?>