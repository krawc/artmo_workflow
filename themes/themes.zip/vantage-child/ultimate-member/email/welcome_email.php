<div style="max-width: 560px; padding: 0px; background: #000000; border-radius: 0px; margin: 40px auto; font-family: Open Sans,Helvetica,Arial; font-size: 15px; color: #666;">
<div style="color: #ffffff; font-weight: normal;">
<div style="text-align: center; font-weight: 600; font-size: 26px; padding: 30px 20px 20px 20px;"><span style="color: #f5f5f5;">{site_name}</span></div>
</div>
<div style="padding: 0 30px 30px 30px; background: #ffffff; border: 2px solid #cccccc;">
<div style="padding: 30px 0; font-size: 24px; text-align: center; line-height: 40px;"><span style="color: #000000;">Welcome!<br />Your account is now active.</span></div>
<div> </div>
<div style="padding: 10px 10px 50px 10px; text-align: center;"><span style="color: #f5f5f5;"><a style="background: #000000; color: #f5f5f5; padding: 12px 30px; text-decoration: none; border-radius: 0px; letter-spacing: 0.3px;" href="{login_url}">LOG-IN</a></span></div>
<div style="padding: 20px; text-align: center;"><span style="color: #000000;">If you have any problems, please contact us at {admin_email}</span></div>
</div>
<div style="color: #999; padding: 20px 30px;">
<div style="text-align: center;"><span style="color: #f5f5f5;">Thank you!</span></div>
<div style="text-align: center;"><span style="color: #f5f5f5;">The <a style="color: #f5f5f5; text-decoration: none;" href="{site_url}">{site_name}</a> Team</span></div>
</div>
</div>