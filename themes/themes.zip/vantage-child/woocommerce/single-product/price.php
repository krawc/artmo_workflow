<?php
/**
 * Single Product Price
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
?>
<p class="price"><?php echo $product->get_price_html(); ?><i class="ion ion-ios-help"
	title="This is the net price; exclusive shipping.
If shipped within a country, then the national VAT will be added.
When shipped to a different country, then import tax may be charged
by the customs of your country.
For a quotation of the total price please go to ENQUIRIES
and send a message and provide your shipping address (County, City, Suburb)."></i></p>
