<?php
/**
 * WCFM plugin templates
 *
 * Footer area
 *
 * @author 		WC Lovers
 * @package 	wcfm/templates/default
 * @version   3.1.2
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wcfm_clearfix"></div>
<div id="wcfm-footer">
	<div class="wcfm-footer-container">
	</div>
</div>