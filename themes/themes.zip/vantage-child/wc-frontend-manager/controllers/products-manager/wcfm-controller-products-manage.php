<?php
/**
 * WCFM plugin controllers
 *
 * Plugin Products Manage Controller
 *
 * @author 		WC Lovers
 * @package 	wcfm/controllers
 * @version   1.0.0
 */

class WCFM_Products_Manage_Controller {

	public function __construct() {
		global $WCFM;

		$this->processing();
	}

	public function processing() {
		global $WCFM, $wpdb, $_POST;

		$wcfm_products_manage_form_data = array();
	  parse_str($_POST['wcfm_products_manage_form'], $wcfm_products_manage_form_data);
	  //print_r($wcfm_products_manage_form_data);
	  $wcfm_products_manage_messages = get_wcfm_products_manager_messages();
	  $has_error = false;

	  if(isset($wcfm_products_manage_form_data['title']) && !empty($wcfm_products_manage_form_data['title'])) {
	  	$is_update = false;
	  	$is_publish = false;

		  	$current_user_id = apply_filters( 'wcfm_current_vendor_id', get_current_user_id() );


	  	// WCFM form custom validation filter
	  	$custom_validation_results = apply_filters( 'wcfm_form_custom_validation', $wcfm_products_manage_form_data, 'product_manage' );
	  	if(isset($custom_validation_results['has_error']) && !empty($custom_validation_results['has_error'])) {
	  		$custom_validation_error = __( 'There has some error in submitted data.', 'wc-frontend-manager' );
	  		if( isset( $custom_validation_results['message'] ) && !empty( $custom_validation_results['message'] ) ) { $custom_validation_error = $custom_validation_results['message']; }
	  		echo '{"status": false, "message": "' . $custom_validation_error . '"}';
	  		die;
	  	}

	  	if(isset($_POST['status']) && ($_POST['status'] == 'draft')) {
	  		$product_status = 'draft';
	  	} else {
	  		if( current_user_can( 'publish_products' ) && apply_filters( 'wcfm_is_allow_publish_products', true ) )
	  			$product_status = 'publish';
	  		else
	  		  $product_status = 'pending';
			}

	  	// Creating new product
			$new_product = apply_filters( 'wcfm_product_content_before_save', array(
				'post_title'   => wc_clean( $wcfm_products_manage_form_data['title'] ),
				'post_status'  => $product_status,
				'post_type'    => 'product',
				'post_excerpt' => apply_filters( 'wcfm_editor_content_before_save', stripslashes( html_entity_decode( $_POST['excerpt'], ENT_QUOTES, 'UTF-8' ) ) ),
				'post_content' => apply_filters( 'wcfm_editor_content_before_save', stripslashes( html_entity_decode( $_POST['description'], ENT_QUOTES, 'UTF-8' ) ) ),
				'post_author'  => $current_user_id
				//'post_name' => sanitize_title($wcfm_products_manage_form_data['title'])
			), $wcfm_products_manage_form_data );

			if(isset($wcfm_products_manage_form_data['pro_id']) && $wcfm_products_manage_form_data['pro_id'] == 0) {
				if ($product_status != 'draft') {
					$is_publish = true;
				}
				$new_product_id = wp_insert_post( $new_product, true );
			} else { // For Update
				$is_update = true;
				$new_product['ID'] = $wcfm_products_manage_form_data['pro_id'];
				unset( $new_product['post_author'] );
				if( ($product_status != 'draft') && (get_post_status( $new_product['ID'] ) == 'publish') ) {
					if( apply_filters( 'wcfm_is_allow_publish_live_products', true ) ) {
						$new_product['post_status'] = 'publish';
					} else {
						$new_product['post_status'] = 'pending';
					}
				} else if( (get_post_status( $new_product['ID'] ) == 'draft') && ($product_status != 'draft') ) {
					$is_publish = true;
				}

			}

			if(!is_wp_error($new_product_id)) {
				// For Update
				if($is_update) $new_product_id = $wcfm_products_manage_form_data['pro_id'];

				// Set Product SKU
				if(isset($wcfm_products_manage_form_data['sku']) && !empty($wcfm_products_manage_form_data['sku'])) {
					update_post_meta( $new_product_id, '_sku', $wcfm_products_manage_form_data['sku'] );
					if( !$is_update ) {
						$unique_sku = wc_product_has_unique_sku( $new_product_id, $wcfm_products_manage_form_data['sku'] );
						if ( ! $unique_sku ) {
							update_post_meta( $new_product_id, '_sku', '' );
							echo '{"status": false, "message": "' . $wcfm_products_manage_messages['sku_unique'] . '", "id": "' . $new_product_id . '", "redirect": "' . get_permalink( $new_product_id ) . '"}';
							$has_error = true;
						}
					}
				} else {
				  update_post_meta( $new_product_id, '_sku', '' );
				}

				//Set manage stock to yes by default and stock quantity to 1

				update_post_meta($new_product_id, '_sold_individually', '1');
				update_post_meta($new_product_id, '_manage_stock', '1');
				update_post_meta($new_product_id, '_stock', '1');

				//Update Artwork Material and Media
				if(isset($wcfm_products_manage_form_data['youTheArtist']) && ($wcfm_products_manage_form_data['youTheArtist'])) {
					update_post_meta( $new_product_id, 'youTheArtist', $wcfm_products_manage_form_data['youTheArtist'] );
				} else {
					update_post_meta( $new_product_id, 'youTheArtist', '0' );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['artistFirstName']) && !empty($wcfm_products_manage_form_data['artistFirstName'])) {
					update_post_meta( $new_product_id, 'artistFirstName', $wcfm_products_manage_form_data['artistFirstName'] );
				}

				//Update Artwork Material and Media
				if(isset($wcfm_products_manage_form_data['artistLastName']) && !empty($wcfm_products_manage_form_data['artistLastName'])) {
					update_post_meta( $new_product_id, 'artistLastName', $wcfm_products_manage_form_data['artistLastName'] );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['series']) && !empty($wcfm_products_manage_form_data['series'])) {
					update_post_meta( $new_product_id, 'series', $wcfm_products_manage_form_data['series'] );
				} else {
					update_post_meta( $new_product_id, 'series', '0' );
				}

				if(isset($wcfm_products_manage_form_data['pro_id']) && $wcfm_products_manage_form_data['pro_id'] == 0) {
					//Update Artwork Series
					if(isset($wcfm_products_manage_form_data['series_name']) && !empty($wcfm_products_manage_form_data['series_name'])) {

						$author_id = $current_user_id;
						$author_cat = 'artist_'.$author_id;
						$author_cat_obj = get_term_by('slug', $author_cat, 'artists_cat');
						$parent_id = $author_cat_obj->term_id;
						$new_slug = sanitize_title($wcfm_products_manage_form_data['series_name']);
						$term_exists = term_exists( $new_slug, 'artists_cat', intval($parent_id));

						if ( $term_exists !== 0 && $term_exists !== null && is_array($term_exists) ) {
							$term_id = $term_exists['term_id'];
							$cat_ids = array($term_id, $parent_id);
							$cat_ids = array_map( 'intval', $cat_ids );
							$cat_ids = array_unique( $cat_ids );
							wp_set_object_terms( $new_product_id, $cat_ids, 'artists_cat' );
						} else {
							$series_term = wp_insert_term(
								$wcfm_products_manage_form_data['series_name'],   // the term
								'artists_cat', // the taxonomy
								array(
									'description' => '',
									'slug' => $new_slug,
									'parent' => intval($parent_id)
								)
							);

							$new_id = $series_term['term_id'];
							$cat_ids = array($new_id, $parent_id);
							$cat_ids = array_map( 'intval', $cat_ids );
							$cat_ids = array_unique( $cat_ids );
							wp_set_object_terms( $new_product_id, $cat_ids, 'artists_cat' );
						}
						update_post_meta( $new_product_id, 'series_name', $wcfm_products_manage_form_data['series_name'] );
					} else {
						$author_id = $current_user_id;
						$author_cat = 'artist_'.$author_id;
						$author_cat_obj = get_term_by('slug', $author_cat, 'artists_cat');
						$parent_id = $author_cat_obj->term_id;
						$cat_ids = array($parent_id);
						$cat_ids = array_map( 'intval', $cat_ids );
						wp_set_object_terms( $new_product_id, $cat_ids, 'artists_cat');
					}
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['priceOnRequest']) && !empty($wcfm_products_manage_form_data['priceOnRequest'])) {
					update_post_meta( $new_product_id, 'priceOnRequest', $wcfm_products_manage_form_data['priceOnRequest'] );
				} else {
					update_post_meta( $new_product_id, 'priceOnRequest', '0' );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['edition']) && !empty($wcfm_products_manage_form_data['edition'])) {
					update_post_meta( $new_product_id, 'edition', $wcfm_products_manage_form_data['edition'] );
				} else {
					update_post_meta( $new_product_id, 'edition', '0' );
				}

				//Update Artwork Material and Media
				if(isset($wcfm_products_manage_form_data['edition_no']) && !empty($wcfm_products_manage_form_data['edition_no'])) {
					update_post_meta( $new_product_id, 'edition_no', $wcfm_products_manage_form_data['edition_no'] );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['edition_t']) && !empty($wcfm_products_manage_form_data['edition_t'])) {
					update_post_meta( $new_product_id, 'edition_t', $wcfm_products_manage_form_data['edition_t'] );
				}

				if(isset($wcfm_products_manage_form_data['edition_name']) && !empty($wcfm_products_manage_form_data['edition_name'])) {
					update_post_meta( $new_product_id, 'edition_name', $wcfm_products_manage_form_data['edition_name'] );
				}

				//Update Artwork Material and Media
				if(isset($wcfm_products_manage_form_data['year']) && !empty($wcfm_products_manage_form_data['year'])) {
					update_post_meta( $new_product_id, 'year', $wcfm_products_manage_form_data['year'] );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['countryProd']) && !empty($wcfm_products_manage_form_data['countryProd'])) {
					update_post_meta( $new_product_id, 'countryProd', $wcfm_products_manage_form_data['countryProd'] );
					wp_set_post_terms( $new_product_id, sanitize_title($wcfm_products_manage_form_data['countryProd']), 'country_cat' );
				} else {
					$auth_country = get_user_meta($current_user_id, 'countryField', true);
					update_post_meta( $new_product_id, 'countryProd', $auth_country);
					wp_set_post_terms( $new_product_id, sanitize_title($auth_country), 'country_cat' );
				}



				//Update Artwork Material and Media
				if(isset($wcfm_products_manage_form_data['materialMedia']) && !empty($wcfm_products_manage_form_data['materialMedia'])) {
					update_post_meta( $new_product_id, 'materialMedia', $wcfm_products_manage_form_data['materialMedia'] );
				}

				//Update Artwork Country of Production
				if(isset($wcfm_products_manage_form_data['dimensions']) && !empty($wcfm_products_manage_form_data['dimensions'])) {
					update_post_meta( $new_product_id, 'dimensions', $wcfm_products_manage_form_data['dimensions'] );
				} else {
					update_post_meta( $new_product_id, 'dimensions', '0' );
				}

				//Update Artwork in frame parameter
				if(isset($wcfm_products_manage_form_data['inFrame']) && !empty($wcfm_products_manage_form_data['inFrame'])) {
					update_post_meta( $new_product_id, 'inFrame', $wcfm_products_manage_form_data['inFrame'] );
				} else {
					update_post_meta( $new_product_id, 'inFrame', '0' );
				}

				//Update Artwork framed length
				if(isset($wcfm_products_manage_form_data['framed_length']) && !empty($wcfm_products_manage_form_data['framed_length'])) {
					update_post_meta( $new_product_id, 'framed_length', $wcfm_products_manage_form_data['framed_length'] );
				}

				//Update Artwork framed height
				if(isset($wcfm_products_manage_form_data['framed_height']) && !empty($wcfm_products_manage_form_data['framed_height'])) {
					update_post_meta( $new_product_id, 'framed_height', $wcfm_products_manage_form_data['framed_height'] );
				}

				//Update Artwork length
				if(isset($wcfm_products_manage_form_data['art_length']) && !empty($wcfm_products_manage_form_data['art_length'])) {
					update_post_meta( $new_product_id, 'art_length', $wcfm_products_manage_form_data['art_length'] );
				}

				//Update Artwork Width
				if(isset($wcfm_products_manage_form_data['art_width']) && !empty($wcfm_products_manage_form_data['art_width'])) {
					update_post_meta( $new_product_id, 'art_width', $wcfm_products_manage_form_data['art_width'] );
				}

				//Update Artwork Height
				if(isset($wcfm_products_manage_form_data['art_height']) && !empty($wcfm_products_manage_form_data['art_height'])) {
					update_post_meta( $new_product_id, 'art_height', $wcfm_products_manage_form_data['art_height'] );
				}

				//Update Artwork Height
				if(isset($wcfm_products_manage_form_data['artDescription']) && !empty($wcfm_products_manage_form_data['artDescription'])) {
					update_post_meta( $new_product_id, 'artDescription', $wcfm_products_manage_form_data['artDescription'] );
				}

				// Set Product Type
				wp_set_object_terms( $new_product_id, $wcfm_products_manage_form_data['product_type'], 'product_type' );

				// Group Products
				$grouped_products = isset( $wcfm_products_manage_form_data['grouped_products'] ) ? array_filter( array_map( 'intval', (array) $wcfm_products_manage_form_data['grouped_products'] ) ) : array();

				// Attributes
				$pro_attributes = array();
				$default_attributes = array();
				if(isset($wcfm_products_manage_form_data['attributes']) && !empty($wcfm_products_manage_form_data['attributes'])) {
					foreach($wcfm_products_manage_form_data['attributes'] as $attributes) {
						if( isset( $attributes['is_active'] ) && !empty($attributes['name']) && !empty($attributes['value'])) {

							$attribute_name = ( $attributes['term_name'] ) ? $attributes['term_name'] : $attributes['name'];

							$is_visible = 0;
							if(isset($attributes['is_visible'])) $is_visible = 1;

							$is_variation = 0;
							if(isset($attributes['is_variation'])) $is_variation = 1;
							if( ( $wcfm_products_manage_form_data['product_type'] != 'variable' ) && ( $wcfm_products_manage_form_data['product_type'] != 'variable-subscription' ) ) $is_variation = 0;

							$is_taxonomy = 0;
							if($attributes['is_taxonomy'] == 1) $is_taxonomy = 1;

							$term_name = '';
							if( $is_taxonomy == 1 ) $term_name = $attributes['term_name'];

							$attribute_id   = wc_attribute_taxonomy_id_by_name( $term_name );
							$options = isset( $attributes['value'] ) ? $attributes['value'] : '';

							if ( is_array( $options ) ) {
								// Term ids sent as array.
								$options = wp_parse_id_list( $options );
							} else {
								// Terms or text sent in textarea.
								$options = 0 < $attribute_id ? wc_sanitize_textarea( wc_sanitize_term_text_based( $options ) ) : wc_sanitize_textarea( $options );
								$options = wc_get_text_attributes( $options );
							}

							if ( empty( $options ) ) {
								continue;
							}

							$attribute = new WC_Product_Attribute();
							$attribute->set_id( $attribute_id );
							$attribute->set_name( wc_clean( $attribute_name ) );
							$attribute->set_options( $options );
							//$attribute->set_position( $attribute_position );
							$attribute->set_visible( $is_visible );
							$attribute->set_variation(  $is_variation );

							$pro_attributes[] = $attribute;

							if( $is_variation ) {
								//$attribute_key = $attribute_name;
								//$value                        = $attribute->is_taxonomy() ? sanitize_title( $value ) : wc_clean( $value ); // Don't use wc_clean as it destroys sanitized characters in terms.
								//$default_attributes[ $attribute_key ] = $value;
							}
						}
					}
				}

				// Set default Attributes
				if( isset( $wcfm_products_manage_form_data['default_attributes'] ) && !empty( $wcfm_products_manage_form_data['default_attributes'] ) ) {
					$default_attributes = array();
					if ( $pro_attributes ) {
						foreach ( $pro_attributes as $p_attribute ) {
							if ( $p_attribute->get_variation() ) {
								$attribute_key = sanitize_title( $p_attribute->get_name() );

								$value = isset( $wcfm_products_manage_form_data['default_attributes'][ "attribute_" . $attribute_key ] ) ? stripslashes( $wcfm_products_manage_form_data['default_attributes'][ "attribute_" . $attribute_key ] ) : '';

								$value                        = $p_attribute->is_taxonomy() ? sanitize_title( $value ) : wc_clean( $value ); // Don't use wc_clean as it destroys sanitized characters in terms.
								$default_attributes[ $attribute_key ] = $value;
							}
						}
					}
				}

				// Process product type first so we have the correct class to run setters.
				$product_type = empty( $wcfm_products_manage_form_data['product_type'] ) ? WC_Product_Factory::get_product_type( $new_product_id ) : sanitize_title( stripslashes( $wcfm_products_manage_form_data['product_type'] ) );
				$classname    = WC_Product_Factory::get_product_classname( $new_product_id, $product_type ? $product_type : 'simple' );
				$product      = new $classname( $new_product_id );
				$errors       = $product->set_props( apply_filters( 'wcfm_product_data_factory', array(
					'virtual'            => isset( $wcfm_products_manage_form_data['is_virtual'] ),
					'sku'                => isset( $wcfm_products_manage_form_data['sku'] ) ? wc_clean( $wcfm_products_manage_form_data['sku'] ) : null,
					'tax_status'         => isset( $wcfm_products_manage_form_data['tax_status'] ) ? wc_clean( $wcfm_products_manage_form_data['tax_status'] ) : null,
					'tax_class'          => isset( $wcfm_products_manage_form_data['tax_class'] ) ? wc_clean( $wcfm_products_manage_form_data['tax_class'] ) : null,
					'weight'             => wc_clean( $wcfm_products_manage_form_data['weight'] ),
					'length'             => wc_clean( $wcfm_products_manage_form_data['length'] ),
					'width'              => wc_clean( $wcfm_products_manage_form_data['width'] ),
					'height'             => wc_clean( $wcfm_products_manage_form_data['height'] ),
					'shipping_class_id'  => absint( $wcfm_products_manage_form_data['shipping_class'] ),
					'upsell_ids'         => isset( $wcfm_products_manage_form_data['upsell_ids'] ) ? array_map( 'intval', (array) $wcfm_products_manage_form_data['upsell_ids'] ) : array(),
					'cross_sell_ids'     => isset( $wcfm_products_manage_form_data['crosssell_ids'] ) ? array_map( 'intval', (array) $wcfm_products_manage_form_data['crosssell_ids'] ) : array(),
					'regular_price'      => wc_clean( $wcfm_products_manage_form_data['regular_price'] ),
					'sale_price'         => wc_clean( $wcfm_products_manage_form_data['sale_price'] ),
					'backorders'         => wc_clean( $wcfm_products_manage_form_data['backorders'] ),
					'stock_status'       => wc_clean( $wcfm_products_manage_form_data['stock_status'] ),
					'product_url'        => esc_url_raw( $wcfm_products_manage_form_data['product_url'] ),
					'button_text'        => wc_clean( $wcfm_products_manage_form_data['button_text'] ),
					'children'           => 'grouped' === $product_type ? $grouped_products : null,
					'attributes'         => $pro_attributes,
					'default_attributes' => $default_attributes,
					'reviews_allowed'    => true,
				), $new_product_id, $product, $wcfm_products_manage_form_data ) );

				if ( is_wp_error( $errors ) ) {
					if( !$has_error )
						echo '{"status": false, "message": "' . $errors->get_error_message() . '", "id": "' . $new_product_id . '", "redirect": "' . get_permalink( $new_product_id ) . '"}';
					$has_error = true;
				}



				/**
				 * @since WC 3.0.0 to set props before save.
				 */
				//do_action( 'woocommerce_admin_process_product_object', $product );
				$product->save();

				// Set Product Category
				if(isset($wcfm_products_manage_form_data['product_cats']) && !empty($wcfm_products_manage_form_data['product_cats'])) {
					$is_first = true;
					foreach($wcfm_products_manage_form_data['product_cats'] as $product_cats) {
						if($is_first) {
							$is_first = false;
							wp_set_object_terms( $new_product_id, (int)$product_cats, 'product_cat' );
						} else {
							wp_set_object_terms( $new_product_id, (int)$product_cats, 'product_cat', true );
						}
					}
				}

				// Set Product Custom Taxonomies
				if(isset($wcfm_products_manage_form_data['product_custom_taxonomies']) && !empty($wcfm_products_manage_form_data['product_custom_taxonomies'])) {
					foreach($wcfm_products_manage_form_data['product_custom_taxonomies'] as $taxonomy => $taxonomy_values) {
						if( !empty( $taxonomy_values ) ) {
							$is_first = true;
							foreach( $taxonomy_values as $taxonomy_value ) {
								if($is_first) {
									$is_first = false;
									wp_set_object_terms( $new_product_id, (int)$taxonomy_value, $taxonomy );
								} else {
									wp_set_object_terms( $new_product_id, (int)$taxonomy_value, $taxonomy, true );
								}
							}
						}
					}
				}

				// Set Product Tags
				if(isset($wcfm_products_manage_form_data['product_tags']) && !empty($wcfm_products_manage_form_data['product_tags'])) {
					wp_set_post_terms( $new_product_id, $wcfm_products_manage_form_data['product_tags'], 'product_tag' );
				}

				if(isset($wcfm_products_manage_form_data['genre_tag']) && !empty($wcfm_products_manage_form_data['genre_tag'])) {
					wp_set_post_terms( $new_product_id, $wcfm_products_manage_form_data['genre_tag'], 'genre_tag' );
				}

				if(isset($wcfm_products_manage_form_data['theme_tag']) && !empty($wcfm_products_manage_form_data['theme_tag'])) {
					wp_set_post_terms( $new_product_id, $wcfm_products_manage_form_data['theme_tag'], 'theme_tag' );
				}

				// Set Product Custom Taxonomies Flat
				if(isset($wcfm_products_manage_form_data['product_custom_taxonomies_flat']) && !empty($wcfm_products_manage_form_data['product_custom_taxonomies_flat'])) {
					foreach($wcfm_products_manage_form_data['product_custom_taxonomies_flat'] as $taxonomy => $taxonomy_values) {
						if( !empty( $taxonomy_values ) ) {
							wp_set_post_terms( $new_product_id, $taxonomy_values, $taxonomy );
						}
					}
				}


				// Set Product Featured Image
				if(isset($wcfm_products_manage_form_data['featured_img']) && !empty($wcfm_products_manage_form_data['featured_img'])) {
					$featured_img_id = $WCFM->wcfm_get_attachment_id($wcfm_products_manage_form_data['featured_img']);
					set_post_thumbnail( $new_product_id, $featured_img_id );
					$current_user_id = get_current_user_id();
					$author_cat = 'artist_'.$current_user_id;
					$author_cat_obj = get_term_by('slug', $author_cat, 'artists_cat');
					$parent_id = $author_cat_obj->term_id;

					wp_set_object_terms( $featured_img_id, (int)$parent_id, 'artists_cat' );

					if(isset($wcfm_products_manage_form_data['product_custom_taxonomies']) && !empty($wcfm_products_manage_form_data['product_custom_taxonomies'])) {
						foreach($wcfm_products_manage_form_data['product_custom_taxonomies'] as $taxonomy => $taxonomy_values) {
							if( !empty( $taxonomy_values ) ) {
								$is_first = true;
								foreach( $taxonomy_values as $taxonomy_value ) {
									if($is_first) {
										$is_first = false;
										wp_set_object_terms( $featured_img_id, (int)$taxonomy_value, $taxonomy );
									} else {
										wp_set_object_terms( $featured_img_id, (int)$taxonomy_value, $taxonomy, true );
									}
								}
							}
						}
					}

					if(isset($wcfm_products_manage_form_data['genre_tag']) && !empty($wcfm_products_manage_form_data['genre_tag'])) {
						wp_set_post_terms( $featured_img_id, $wcfm_products_manage_form_data['genre_tag'], 'genre_tag' );
					}

					// Set Product Custom Taxonomies Flat
					if(isset($wcfm_products_manage_form_data['product_custom_taxonomies_flat']) && !empty($wcfm_products_manage_form_data['product_custom_taxonomies_flat'])) {
						foreach($wcfm_products_manage_form_data['product_custom_taxonomies_flat'] as $taxonomy => $taxonomy_values) {
							if( !empty( $taxonomy_values ) ) {
								wp_set_post_terms( $featured_img_id, $taxonomy_values, $taxonomy );
							}
						}
					}
				}
				elseif(isset($wcfm_products_manage_form_data['featured_img']) && empty($wcfm_products_manage_form_data['featured_img'])) {
					delete_post_thumbnail( $new_product_id );
				}

				// Set product basic options for simple and external products
				if( ( $wcfm_products_manage_form_data['product_type'] == 'variable' ) || ( $wcfm_products_manage_form_data['product_type'] == 'variable-subscription' ) ) {
					// Create Variable Product Variations
					if(isset($wcfm_products_manage_form_data['variations']) && !empty($wcfm_products_manage_form_data['variations'])) {
					  foreach($wcfm_products_manage_form_data['variations'] as $variations) {
					  	$variation_status     = isset( $variations['enable'] ) ? 'publish' : 'private';
					  	$variation_id = absint ( $variations['id'] );

					  	// Generate a useful post title
					  	$variation_post_title = sprintf( __( 'Variation #%s of %s', 'woocommerce' ), absint( $variation_id ), esc_html( get_the_title( $new_product_id ) ) );

					  	if ( ! $variation_id ) { // Adding New Variation
								$variation = array(
									'post_title'   => $variation_post_title,
									'post_content' => '',
									'post_status'  => $variation_status,
									'post_author'  => $current_user_id,
									'post_parent'  => $new_product_id,
									'post_type'    => 'product_variation'
								);

								$variation_id = wp_insert_post( $variation );
							}

							// Only continue if we have a variation ID
							if ( ! $variation_id ) {
								continue;
							}

							// Set Variation Thumbnail
							$variation_img_id = 0;
							if(isset($variations['image']) && !empty($variations['image'])) {
								$variation_img_id = $WCFM->wcfm_get_attachment_id($variations['image']);
							}

							// Update Attributes
							$updated_attribute_keys = array();
							$var_attributes = array();
							if ( $pro_attributes ) {
								foreach ( $pro_attributes as $p_attribute ) {
									if ( $p_attribute->get_variation() ) {
										$attribute_key = sanitize_title( $p_attribute->get_name() );

										$updated_attribute_keys[] = "attribute_" . $attribute_key;
										$value = isset( $variations[ "attribute_" . $attribute_key ] ) ? stripslashes( $variations[ "attribute_" . $attribute_key ] ) : '';

										$value                        = $p_attribute->is_taxonomy() ? sanitize_title( $value ) : wc_clean( $value ); // Don't use wc_clean as it destroys sanitized characters in terms.
										$var_attributes[ $attribute_key ] = $value;
									}
								}
							}

							$wc_variation    = new WC_Product_Variation( $variation_id );
							$errors       = $wc_variation->set_props( apply_filters( 'wcfm_product_variation_data_factory', array(
								//'status'            => 'publish' //isset( $variations['enable'] ) ? 'publish' : 'private',
								'menu_order'        => wc_clean( $variations['menu_order'] ),
								'regular_price'     => wc_clean( $variations['regular_price'] ),
								'sale_price'        => wc_clean( $variations['sale_price'] ),
								'manage_stock'      => isset( $variations['manage_stock'] ),
								'stock_quantity'    => wc_clean( $variations['stock_qty'] ),
								'backorders'        => wc_clean( $variations['backorders'] ),
								'stock_status'      => wc_clean( $variations['stock_status'] ),
								'image_id'          => wc_clean( $variation_img_id ),
								'attributes'        => $var_attributes,
								'sku'               => isset( $variations['sku'] ) ? wc_clean( $variations['sku'] ) : '',
							), $new_product_id, $variation_id, $variations, $wcfm_products_manage_form_data ) );

							if ( is_wp_error( $errors ) ) {
								if( !$has_error )
									echo '{"status": false, "message": "' . $errors->get_error_message() . '", "id": "' . $new_product_id . '", "redirect": "' . get_permalink( $new_product_id ) . '"}';
								$has_error = true;
							}

							$wc_variation->save();

							do_action( 'after_wcfm_product_variation_meta_save', $new_product_id, $variation_id, $variations, $wcfm_products_manage_form_data );
						}
					}

					// Remove Variations
					if(isset($_POST['removed_variations']) && !empty($_POST['removed_variations'])) {
						foreach($_POST['removed_variations'] as $removed_variations) {
							wp_delete_post($removed_variations, true);
						}
					}

					$product->get_data_store()->sync_variation_names( $product, wc_clean( $wcfm_products_manage_form_data['title'] ), wc_clean( $wcfm_products_manage_form_data['title'] ) );
				}

				do_action( 'after_wcfm_products_manage_meta_save', $new_product_id, $wcfm_products_manage_form_data );

				if(!$has_error) {
					if( get_post_status( $new_product_id ) == 'publish' ) {
						if(!$has_error) echo '{"status": true, "message": "' . apply_filters( 'product_published_message', $wcfm_products_manage_messages['product_published'], $new_product_id ) . '", "redirect": "' . apply_filters( 'wcfm_product_save_publish_redirect', get_wcfm_products_url( ) ) . '", "id": "' . $new_product_id . '", "title": "' . get_the_title( $new_product_id ) . '"}';
					} elseif( get_post_status( $new_product_id ) == 'pending' ) {
						if(!$has_error) echo '{"status": true, "message": "' . apply_filters( 'product_pending_message', $wcfm_products_manage_messages['product_pending'], $new_product_id ) . '", "redirect": "' . apply_filters( 'wcfm_product_save_pending_redirect', get_wcfm_products_url( ) ) . '", "id": "' . $new_product_id . '", "title": "' . get_the_title( $new_product_id ) . '"}';
					} else {
						if(!$has_error) echo '{"status": true, "message": "' . apply_filters( 'product_saved_message', $wcfm_products_manage_messages['product_saved'], $new_product_id ) . '", "redirect": "' . apply_filters( 'wcfm_product_save_draft_redirect',  get_wcfm_products_url( ) ) . '", "id": "' . $new_product_id . '"}';
					}
				}
				die;
			}
		} else {
			echo '{"status": false, "message": "' . $wcfm_products_manage_messages['no_title'] . '"}';
		}
	  die;
	}
}
